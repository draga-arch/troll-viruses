this trojan is not joke

im not responsible for any damage done to your computer
creator: draga arch