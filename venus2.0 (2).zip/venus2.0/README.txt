This is a gdi malware made by draga arch
youtube:https://www.youtube.com/@mrflimflamrblx/featured

Im not responsible for any damages made to your device.
:)

This gdi malware doesnt overwrite the MBR or delete any crtical system files.
Run on vm.