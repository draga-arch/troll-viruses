this malware was made by draga arch


Im Not responsible of any damages made to your computer
please run on vm only.

