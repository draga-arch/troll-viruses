This is a malicious file.
Type: Trojan.
Run as administator to launch this program

https://github.com/draga-arch
This file was made for a joke and i will NOT BE RESPONSIBLE FOR DAMAGES.